function changeImage()
{

document.getElementById('theimage').src="images/microusb.png";
}
function changeImageBack()
{

document.getElementById('theimage').src="images/charger.png";
}